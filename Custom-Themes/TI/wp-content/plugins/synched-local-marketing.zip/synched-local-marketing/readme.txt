=== Plugin Name ===
Contributors: 
Tags: 
Donate link: 
Requires at least: 
Tested up to: 
Stable tag: 
Requires PHP: 
License: GPLv2 or later
License URI: 



== Description ==



= Features include: =
* 

= Important Links: =
* 



== Installation ==

1. Upload the plugin in `Plugins > Add New` or FTP into the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.


== Frequently Asked Questions ==




== Screenshots ==



== Changelog ==

= 1.4.1 =
* 



* Initial release at 

== Upgrade Notice ==
