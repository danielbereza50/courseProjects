<h1>Synched Local Marketing Settings</h1>

<form method="POST">
    <label for="awesome_text">The Account Name</label>
    <div><input type="text" name="awesome_text" id="awesome_text" value="<?php echo $value1; ?>"></div>
      <label for="awesome_text">The Website URL</label>
   <div><input type="text" name="awesome_text" id="awesome_text" value="<?php  echo $value2; ?>"></div>
</form>

<?php 
# The view is responsible to display the data provided by the model as constructed by the controller.

?>