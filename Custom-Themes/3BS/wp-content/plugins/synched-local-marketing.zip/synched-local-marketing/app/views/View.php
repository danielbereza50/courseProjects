<?php 

# The view is responsible to display the data provided by the model as constructed by the controller.




?>