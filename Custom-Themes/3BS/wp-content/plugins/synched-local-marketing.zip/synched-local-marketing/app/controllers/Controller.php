<?php

# The controller would contain template tags and functions that the view would utilize.

class Controller //extends MvcPublicController {	
{

}
?>