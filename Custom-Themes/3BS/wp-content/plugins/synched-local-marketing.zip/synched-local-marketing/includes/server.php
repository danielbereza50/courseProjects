<?php

# Every class should have a single purpose, all of it's functions satisfying a single goal	
# SIMPLE design pattern, amongst others
# algorithmic run time efficiency

class class1 {

    public function test() {
?>

        <script>
   jQuery(document).ready(function(){ 
   
   // make a call to the server
   jQuery.ajax({


    )}
 });  
</script>

<?
    }
    
}








