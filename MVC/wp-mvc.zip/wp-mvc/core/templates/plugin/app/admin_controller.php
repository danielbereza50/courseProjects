<?php echo "<?php\n"; ?>

class Admin<?php echo $name_pluralized ?>Controller extends MvcAdminController {

    var $default_columns = array('id', 'name');

}
